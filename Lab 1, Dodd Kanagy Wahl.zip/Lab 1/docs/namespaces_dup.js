var namespaces_dup =
[
    [ "Lab0Main", "namespace_lab0_main.html", [
      [ "led_brightness", "namespace_lab0_main.html#a337831b8d269b0e4579c9ba87c53d39b", null ],
      [ "led_setup", "namespace_lab0_main.html#ad5b048da8ebe4fcfcbc3e153801e7225", null ],
      [ "ch1m", "namespace_lab0_main.html#a8e02b5ddb95b8fbddd25d94eaf6b0bfb", null ],
      [ "cTime", "namespace_lab0_main.html#adc784dbdf0ec173429c9d6681a1b0f8c", null ],
      [ "tInit", "namespace_lab0_main.html#a21177f30edaec52e6fc674d13741cb08", null ]
    ] ]
];