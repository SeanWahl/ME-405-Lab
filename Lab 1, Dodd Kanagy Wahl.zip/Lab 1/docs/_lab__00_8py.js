var _lab__00_8py =
[
    [ "led_brightness", "_lab__00_8py.html#a1935af8b79d3edb8f5a8e3719cf9e2c9", null ],
    [ "led_setup", "_lab__00_8py.html#a0a1824d65580c440ddd4da3c4d522282", null ]
];