var searchData=
[
  ['tinit_0',['tInit',['../_lab0_main_8py.html#a21177f30edaec52e6fc674d13741cb08',1,'Lab0Main']]]
];
