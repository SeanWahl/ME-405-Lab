var searchData=
[
  ['lab0main_2epy_0',['Lab0Main.py',['../_lab0_main_8py.html',1,'']]],
  ['led_5fbrightness_1',['led_brightness',['../_lab0_main_8py.html#a337831b8d269b0e4579c9ba87c53d39b',1,'Lab0Main']]],
  ['led_5fsetup_2',['led_setup',['../_lab0_main_8py.html#ad5b048da8ebe4fcfcbc3e153801e7225',1,'Lab0Main']]]
];
