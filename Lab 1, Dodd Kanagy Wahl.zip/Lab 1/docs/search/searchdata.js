var indexSectionsWithContent =
{
  0: "l",
  1: "l",
  2: "l"
};

var indexSectionNames =
{
  0: "all",
  1: "files",
  2: "functions"
};

var indexSectionLabels =
{
  0: "All",
  1: "Files",
  2: "Functions"
};

