var searchData=
[
  ['ch1m_0',['ch1m',['../_lab0_main_8py.html#a8e02b5ddb95b8fbddd25d94eaf6b0bfb',1,'Lab0Main']]],
  ['ctime_1',['cTime',['../_lab0_main_8py.html#adc784dbdf0ec173429c9d6681a1b0f8c',1,'Lab0Main']]]
];
